# Checkout transparente Pagseguro em PHP

* Altere os dados no arquivo config.php 

* Acesse https://sandbox.pagseguro.uol.com.br Para obter os dados do SANDBOX para o ambiente de testes

* Para o ambiente de produção, altere $SANDBOX_ENVIRONMENT para false em config.php
